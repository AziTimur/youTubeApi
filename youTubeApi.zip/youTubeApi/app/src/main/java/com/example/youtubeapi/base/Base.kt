package com.example.youtubeapi.base
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


abstract class Base<VB: Vi >: AppCompatActivity() {

    protected lateinit var viewBinding: VB
    protected abstract fun inflateViewBinding(): VB

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = inflateViewBinding()
        setContentView(viewBinding.root)
        checkInternet()
        setUI()
        clickListener()

    }

    abstract fun clickListener() // внутри этого метода обрабатываем все клики

    abstract fun setUI() // инициализация UI

    abstract fun checkInternet()

}